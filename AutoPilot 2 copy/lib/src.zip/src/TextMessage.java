
public class TextMessage {
	String text;
	String sender;
	boolean isSender;
	
	public TextMessage(String text, String sender, boolean isSender) {
		this.text = text;
		this.sender = sender;
		this.isSender = isSender;
	}
}
